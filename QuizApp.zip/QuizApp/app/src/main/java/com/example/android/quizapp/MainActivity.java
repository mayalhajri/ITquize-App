package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;
import android.view.View;
import android.widget.RadioGroup;
import android.text.TextUtils;

public class MainActivity extends AppCompatActivity {
    private static int corrct;
    private static int inCorrct;
    private static int totalResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showResult(View view) {
        //Q1
        int bits = 0;
        EditText answerQ1 = (EditText) findViewById(R.id.editText_bits);
        if (!TextUtils.isEmpty(answerQ1.getText().toString())) {
            bits = Integer.parseInt(answerQ1.getText().toString());
        }
        //Q2
        if (question1Answer()) {
            corrct++;
        } else {
            inCorrct++;
        }
        //Q3
        if (question2Answer()) {
            corrct++;
        } else {
            inCorrct++;
        }
        //Q5
        if (question5Answer()) {
            corrct++;
        } else {
            inCorrct++;
        }
        //Q4
        CheckBox q4CheckBox1 = (CheckBox) findViewById(R.id.Q4_ans1);
        boolean q4Check1 = q4CheckBox1.isChecked();
        CheckBox q4CheckBox2 = (CheckBox) findViewById(R.id.Q4_ans2);
        boolean q4Check2 = q4CheckBox2.isChecked();
        CheckBox q4CheckBox3 = (CheckBox) findViewById(R.id.Q4_ans3);
        boolean q4Check3 = q4CheckBox3.isChecked();
        totalResult = calculateResult(bits, q4Check1, q4Check2, q4Check3);
        String grade;
        //grade
        if (totalResult >= 75)
            grade = getResources().getString(R.string.gradA);
        else if ((totalResult >= 60) && (totalResult < 75))
            grade = getResources().getString(R.string.gradB);
        else if ((totalResult >= 50) && (totalResult < 60))
            grade = getResources().getString(R.string.gradC);
        else if ((totalResult >= 40) && (totalResult < 50))
            grade = getResources().getString(R.string.gradD);
        else
            grade = getResources().getString(R.string.failed);
        String score = getResources().getString(R.string.score) + totalResult + getResources().getString(R.string.points) + "(" + totalResult + "% )" + "\n" + grade;
        Toast.makeText(this, score, Toast.LENGTH_SHORT).show();
    }

    private boolean question1Answer() {
        RadioGroup radioGroup1 = (RadioGroup) findViewById(R.id.radioGroupQ1);
        int q2Ans = R.id.Q2_ans1;
        if (radioGroup1.getCheckedRadioButtonId() == q2Ans) {
            return true;
        }
        return false;
    }

    private boolean question2Answer() {
        RadioGroup radioGroup2 = (RadioGroup) findViewById(R.id.radioGroupQ2);
        int q3Ans = R.id.Q3_ans2;
        if (radioGroup2.getCheckedRadioButtonId() == q3Ans) {
            return true;
        }
        return false;
    }

    private boolean question5Answer() {
        RadioGroup radioGroup5 = (RadioGroup) findViewById(R.id.radioGroupQ5);
        int q5Ans = R.id.Q5_ans2;
        if (radioGroup5.getCheckedRadioButtonId() == q5Ans) {
            return true;
        }
        return false;
    }

    private int calculateResult(int bits, boolean q4Ans1, boolean q4Ans2, boolean q4Ans3) {
        int present;
        if (bits == 8) {
            corrct++;
        }
        if (q4Ans2 && q4Ans3 && !q4Ans1) {
            corrct++;
        } else {
            inCorrct++;
        }
        present = corrct * 20;
        return present;
    }

    public void showResultDetails(View view) {
        TextView quantityTextView = (TextView) findViewById(R.id.show);
        quantityTextView.setText(String.valueOf(displayResult()));
    }

    private String displayResult() {
        String showMessage = "\n" + getResources().getString(R.string.score) + totalResult + "% ";
        showMessage += "\n" + getResources().getString(R.string.corrctAns) + corrct;
        showMessage += "\n" + getResources().getString(R.string.inCorrectAns) + inCorrct + "\n";
        return showMessage;
    }
}